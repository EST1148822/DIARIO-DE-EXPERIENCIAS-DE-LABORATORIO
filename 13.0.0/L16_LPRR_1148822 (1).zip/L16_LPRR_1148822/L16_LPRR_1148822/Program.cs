﻿internal class Program
{
    static void Main(string[] args)
    {
        int suma = 0;
        int negativo = 0;
        Random numero = new Random();

        int[,] matriz = new int[40, 50];
        for (int f = 0; f < 40; f++)
        {
            for (int c = 0; c < 50; c++)
            {
                matriz[f, c] = numero.Next(-50, 50); 
            }
        }
        for (int f = 0; f < 40; f++)
        {
            for (int c = 0; c < 50; c++)
            {
                if (matriz[f, c] > 0)
                {
                    suma = suma + matriz[f, c];
                }
                else
                {
                    negativo = negativo + matriz[f, c];
                }
            }
        }
        Console.WriteLine("La suma de los numeros positivos de la matriz da como reultado: " + suma);
        Console.WriteLine("La suma de los numeros negativos de la matriz da como reultado: " + negativo);

    }
}
